沿用 `schema_version=1`。把 **QA-012**（Question and Answer，第 12 筆問答）接回 `qa/registry.json` 的 `interactions`，將「匯出成功後維持原設定」列為候選需求。以下是草稿，專案檔案未變更。

| 記錄位置 | 草稿內容 |
|---|---|
| 原始問答 | 沿用 `QA-012`。原問題 `question_text` 為「匯出成功後原設定應怎樣？」，原回答 `answer_text` 為「維持原設定」。填 `answered_by="使用者"`、`answer_status="answered"`、`capture="verbatim"`。 |
| 問答時間 | `asked_at=null`、`answered_at=null`。日後實際補登時，`recorded_at` 和 `answer_recorded_at` 才記入帶時區的登錄時間。 |
| 需求草稿 | `requirements` 的 `text` 為「匯出成功後，應維持匯出前的設定。」填 `status="proposed"`、`decision_refs=[]`、`confirmation=null`。待取得專案中可用的需求編號，再將該編號加入 QA-012 的 `related_ids`，即可從原話追到需求。 |
| 決策缺口 | 原決策時間確實無法取得。`decisions` 本次無新增項目，這條規則尚未具備正式驗收依據。若日後有權決策者重新採納，才以當次決策人、實際時間與證據建立新決策，並以 `interaction_refs=["QA-012"]` 指回歷史原話。 |
