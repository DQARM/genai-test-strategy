# 輸出控制｜接回審查修正

沿用本機專案。累計已問 5 題，本批 5/5，新增 0 題。使用者選擇原文「先產出，不再問」。原 session 最後列出的問答編號為 QA-005；原 registry 沒有對應逐字稿。本次主動提供的處置見 QA-006，回答時間為 2026-11-14T11:00:00+08:00，連同個別處置保存於 DEC-002。先前採納規則仍見 DEC-001。

- 審查起點為 REV-001，原設計指紋 bc0f8bdcc3405d1bf9ecc0c487319556113c5b9ff08731ee84fefb627f7ed1f1。原結果有四輪紀錄及兩項發現，缺少原交接包與其輸入指紋，接回時以完整設計指紋及來源原文核對。歷史基線 BL-001 所屬版本另存於其快照。
- F-001 已修正。TC-001 第 2 版在 reset 後以 inspect output 確認 OFF，再執行 evaluate。REQ-001、AC-001 的 evaluate 後 ON 規則沿用。依據為 inputs/spec.md 與 inputs/harness.md 第 1 行，兩者均已核對全文。
- F-002 延後決定。待辦 Q-001 追蹤重啟後到首次 evaluate 前的輸出。負責人待指派，建議由有權決定此規格的產品負責人在設計重啟驗收前處置。
- 新設計指紋 66b1bbdc5f3c8cba14d2f38efca651db19f92df3ee5db74ccd7c92da4efe7afd。案例可以依設計執行，目前等待獨立複核，尚未取得新版核可或實測證據。報告為 qa/report.html。
- 同工作區請由新審查階段依 qa/review-packs/REV-002/HANDOFF.md 複核。交接包驗證無錯誤；QA-006 因使用者主動提供處置，只有回答原文，沒有原提問。
- 只保存在本機。這次未增加訪談題數，使用者下次另行提出需求時再接續。

編號數字為各類流水號。QA（Question and Answer）保存問答，DEC（Decision）追蹤決策，REV（Review）定位審查與交接，F（Finding）追蹤發現，TC（Test Case）定位案例，REQ（Requirement）定位需求，AC（Acceptance Criterion）定位驗收條件，Q（Question）追蹤待辦，BL（Baseline）定位基線。
