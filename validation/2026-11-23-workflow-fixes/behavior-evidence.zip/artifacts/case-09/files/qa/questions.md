# 規格問題交接單

## 編號說明

ID＝Identifier（識別碼）。數字後綴是各類流水號，不代表優先度、版本、核可或測試結果。非數字後綴是專案標籤。

- DEC＝Decision；決策；記錄人的決定與依據
- F＝Finding；審查發現；追蹤具體問題與處置
- Q＝Question；待釐清問題；追蹤未決事項、責任人與確認時點
- SRC＝Source；資料來源；追蹤文件、操作指南或其他依據
- TC＝Test Case；測試案例；保存完整前置、步驟、判準與證據要求

由 registry.questions 產生；這是未決清單，不是逐字訪談或已確認規格。
請另存填答副本；重新匯出會更新本檔。回覆需保留回答者、日期與依據，再由設計端更新原問答／決策。空白不是同意。
列出 open 與 deferred；已標阻塞優先，其次未分級、重要及稍後。排序不代表已接受風險。
設計版本：`66b1bbdc5f3c8cba14d2f38efca651db19f92df3ee5db74ccd7c92da4efe7afd`

## 未決摘要

| 問題 | 狀態／急迫性 | 內容 | 責任人／確認時點 | 影響 |
|---|---|---|---|---|
| Q-001 | deferred / later | 產品重啟完成後、第一次 evaluate 之前，output 應為何值？是否取決於重啟前狀態？ | unassigned / 要將重啟納入驗收或設計重啟案例前 | TC-001 |

## 已登錄來源的閱讀範圍

僅顯示登錄紀錄；未登錄的文件、未讀部分及尚未分析的內容不視為已審完。

- SRC-SPEC：已讀指定範圍（依紀錄）；已讀：inputs/spec.md 第 1 行（全文）；未讀／限制：
- SRC-HARNESS：已讀指定範圍（依紀錄）；已讀：inputs/harness.md 第 1 行（全文）；未讀／限制：

## Q-001：產品重啟完成後、第一次 evaluate 之前，output 應為何值？是否取決於重啟前狀態？

- 類型：未分類
- 分歧與影響：F-002 涉及重啟後的測試判準，規格僅承諾 evaluate 後為 ON。現有 TC-001 自行建立 OFF 初態，只涵蓋 evaluate；本項僅影響未來的重啟驗證。
- 責任人：unassigned；建議轉交：有權決定重啟規格的產品負責人
- 確認時點：要將重啟納入驗收或設計重啟案例前；阻塞階段：未列
- 影響項目：TC-001

來源與具體定位：

- [SRC-SPEC](../inputs/spec.md)；版本：未提供；SHA256：f574cfbae3eedc1dc70434c467a38a47a2b550511edfdef06c16521d9c0ba691
- SRC-SPEC／閱讀 2／摘錄 1：inputs/spec.md:1；Synthetic test rule: after evaluate, output ON.

回答（待填）：

回答者／日期／依據（待填）：

