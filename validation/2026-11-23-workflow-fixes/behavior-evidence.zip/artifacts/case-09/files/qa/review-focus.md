# 修正後複核重點

對照 qa/reviews/REV-001.json 與 qa/decisions/DEC-002.md，複核下列兩項。

- F-001。檢查 TC-001 第 2 版是否在隔離 fixture 中先 reset，再以 inspect output 確認並記下 OFF 才進入 evaluate；初態無法確認時應停止並記無法判定。依 inputs/harness.md 第 1 行及原案例資料核對。
- F-002。對照 inputs/spec.md 第 1 行，確認案例仍只以 evaluate 後的 ON 判定產品行為。重啟的判準待產品決策人答覆 Q-001。

保留原來的已選範圍與斷言覆蓋，複核者按實際檢查範圍回報。

編號數字為各類流水號。REV（Review）定位審查，DEC（Decision）記錄決策，F（Finding）追蹤發現，TC（Test Case）定位案例，Q（Question）追蹤待辦。
