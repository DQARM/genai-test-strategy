# 需求風險評估

## 編號說明

ID＝Identifier（識別碼）。以下為本專案採用的前綴含義；不是通用強制標準。
純數字後綴如 01／001 是該類別的流水號，不代表優先度、版本、確認狀態或測試結果。
非數字後綴是專案標籤，具體含義須依來源記錄確認；RISK／RUN 本身是英文單字。

| 前綴 | 英文來源 | 中文意思 | 用途 |
|---|---|---|---|
| DEC | Decision | 決策 | 記錄人的決定與依據 |
| REQ | Requirement | 需求 | 追蹤單一產品需求 |
| RISK | Risk | 風險 | 追蹤失敗情境、影響與取捨 |
| RUN | Run | 測試執行紀錄 | 保存某次實際執行的觀察與證據 |
| SRC | Source | 資料來源 | 追蹤文件、操作指南或其他依據 |
| TC | Test Case | 測試案例 | 保存完整前置、步驟、判準與證據要求 |

由 registry.json 產生。評估狀態與需求確認狀態分開；未知不等於低風險，案例連結不是實測證據。

## 分級準則

```json
{
  "status": "confirmed",
  "decision_refs": [
    "DEC-001"
  ],
  "severity": {
    "high": "Synthetic main function lost",
    "low": "Synthetic cosmetic effect"
  },
  "likelihood": {
    "high": "Observed often in synthetic fixture",
    "low": "Rare in synthetic fixture"
  },
  "priority": {
    "P1": "Selected synthetic scope",
    "P2": "Later synthetic scope"
  }
}
```

| 需求 | 評估狀態 | 風險／失敗情境／後果 | 嚴重度 | 可能性 | 測試優先序 | 評估說明 | 關聯案例 |
|---|---|---|---|---|---|---|---|
| REQ-001 | 已有初評（待確認） | RISK-001 / OFF after evaluate / 在已選的隔離模組中，evaluate 返回後主要輸出未切換為 ON。現有資料無法判定實機或下游影響。 | high | 待評估／資料不足 | P1 | 原需求及驗收條件沿用已確認版本。針對新增的一次失效與一次環境阻塞提出修訂初評，尚待風險決策者採納。舊版評估與採納依據保存在原基線。；依據：SRC-SPEC, SRC-001, SRC-003, SRC-002 | TC-001 |

## 風險詳情與依據

### RISK-001

```json
{
  "id": "RISK-001",
  "failure": "OFF after evaluate",
  "impact": "在已選的隔離模組中，evaluate 返回後主要輸出未切換為 ON。現有資料無法判定實機或下游影響。",
  "requirement_ids": [
    "REQ-001"
  ],
  "severity": "high",
  "severity_rationale": "沿用 high。失效後主要輸出控制功能不可用，符合既有 high 定義。這次回報未見新的後果。",
  "likelihood": "unknown",
  "likelihood_rationale": "在 fixture-build-7／synthetic-lab，RUN-001 與其附件證實一次從 OFF 執行 evaluate、返回後仍為 OFF。RUN-002 在治具無電時受阻，並未執行 evaluate。缺完整有效執行次數、觀測期間及現場暴露量，發生可能性維持 unknown。",
  "uncertainty": "high：這組資料把「是否曾在這個版本和實驗環境看到失效」縮小為一次有日誌的觀察。重現條件、根因、其他版本、現場頻率與實機影響仍未知。",
  "priority": "P1",
  "rationale": "維持既有 P1（本輪已選範圍）。案例的返回後輸出斷言可直接檢出已觀察失效。待有修復版本及供電可用的治具時，優先沿用該案例回歸。",
  "source_refs": [
    "SRC-SPEC",
    "SRC-001",
    "SRC-003",
    "SRC-002"
  ],
  "source_citations": [
    {
      "source_id": "SRC-SPEC",
      "reading_seq": 1,
      "finding_index": 1
    },
    {
      "source_id": "SRC-001",
      "reading_seq": 1,
      "finding_index": 1
    },
    {
      "source_id": "SRC-001",
      "reading_seq": 1,
      "finding_index": 2
    },
    {
      "source_id": "SRC-003",
      "reading_seq": 1,
      "finding_index": 1
    },
    {
      "source_id": "SRC-002",
      "reading_seq": 1,
      "finding_index": 1
    },
    {
      "source_id": "SRC-002",
      "reading_seq": 1,
      "finding_index": 2
    }
  ],
  "revision": 2,
  "residual_risk": "現有案例可檢出異常，尚無修復後通過或獨立重現的證據。供電不足時無產品輸出可觀察，該次結果只能記為環境阻塞。"
}
```

