# 來源閱讀紀錄

## 編號說明

ID＝Identifier（識別碼）。以下為本專案採用的前綴含義；不是通用強制標準。
純數字後綴如 01／001 是該類別的流水號，不代表優先度、版本、確認狀態或測試結果。
非數字後綴是專案標籤，具體含義須依來源記錄確認；RISK／RUN 本身是英文單字。

| 前綴 | 英文來源 | 中文意思 | 用途 |
|---|---|---|---|
| SHA | 待確認 | 待確認 | 請確認本專案定義，不猜測英文來源 |
| SRC | Source | 資料來源 | 追蹤文件、操作指南或其他依據 |
| TC | Test Case | 測試案例 | 保存完整前置、步驟、判準與證據要求 |
| UTF | 待確認 | 待確認 | 請確認本專案定義，不猜測英文來源 |

由 registry.sources 產生。閱讀狀態、來源採納與本輪用途分開；登錄或檔案指紋不證明已讀。

閱讀紀錄序號與摘錄序號皆從 1 起算，僅在該來源／紀錄內定位；不是版本、優先度或核可。

## SRC-SPEC

閱讀：已讀指定範圍（依紀錄）；採納：confirmed；用途：normative

```json
{
  "reading_state": {
    "status": "scoped",
    "label": "已讀指定範圍（依紀錄）",
    "seq": 1,
    "read_scope": [
      "whole synthetic file"
    ],
    "unread_scope": [],
    "limitations": []
  },
  "readings": [
    {
      "seq": 1,
      "source_sha256": "f574cfbae3eedc1dc70434c467a38a47a2b550511edfdef06c16521d9c0ba691",
      "status": "scoped",
      "depth": "content",
      "purpose": "Synthetic tool regression",
      "method": "Read synthetic UTF-8 fixture",
      "read_scope": [
        "whole synthetic file"
      ],
      "unread_scope": [],
      "limitations": [],
      "findings": [
        {
          "locator": "whole file",
          "type": "quote",
          "text": "Synthetic test rule: after evaluate, output ON.\n"
        }
      ],
      "evidence_refs": [],
      "read_at": null,
      "recorded_at": "2026-11-13T00:00:00Z"
    }
  ]
}
```

## SRC-HARNESS

閱讀：已讀指定範圍（依紀錄）；採納：confirmed；用途：harness

```json
{
  "reading_state": {
    "status": "scoped",
    "label": "已讀指定範圍（依紀錄）",
    "seq": 1,
    "read_scope": [
      "whole synthetic file"
    ],
    "unread_scope": [],
    "limitations": []
  },
  "readings": [
    {
      "seq": 1,
      "source_sha256": "6050ea2d883af7e763867cd2cc9320f8347986265482bc05f42bc28ee325c140",
      "status": "scoped",
      "depth": "content",
      "purpose": "Synthetic tool regression",
      "method": "Read synthetic UTF-8 fixture",
      "read_scope": [
        "whole synthetic file"
      ],
      "unread_scope": [],
      "limitations": [],
      "findings": [
        {
          "locator": "whole file",
          "type": "quote",
          "text": "Synthetic harness: reset, evaluate, inspect output; isolated state.\n"
        }
      ],
      "evidence_refs": [],
      "read_at": null,
      "recorded_at": "2026-11-13T00:00:00Z"
    }
  ]
}
```

## SRC-001

閱讀：已讀指定範圍（依紀錄）；採納：confirmed；用途：experience

```json
{
  "reading_state": {
    "status": "scoped",
    "label": "已讀指定範圍（依紀錄）",
    "seq": 1,
    "read_scope": [
      "第 2–7、704–705、708–722 行",
      "執行編號、狀態、案例、版本、環境、時間、回報者及步驟的實際觀察和證據清單。"
    ],
    "unread_scope": [
      "未逐欄閱讀內嵌的重複設計／需求／案例快照與 Git 狀態清單。"
    ],
    "limitations": [
      "同一份回報與附檔屬同一事件，缺獨立重現、完整執行分母、現場暴露量與統計觀測期間。"
    ]
  },
  "readings": [
    {
      "source_sha256": "7c1bc0f9a10f3e9657e449a65c82a7461d1d291737bb7367f4bedc2475314042",
      "status": "scoped",
      "depth": "content",
      "purpose": "判讀回報者提供的合成紀錄，評估輸出控制風險與可執行性。",
      "method": "解析 UTF-8 JSON，按 JSON 路徑與帶行號的原文核對，使用 check-run 檢查快照及證據完整性。",
      "read_scope": [
        "第 2–7、704–705、708–722 行",
        "執行編號、狀態、案例、版本、環境、時間、回報者及步驟的實際觀察和證據清單。"
      ],
      "unread_scope": [
        "未逐欄閱讀內嵌的重複設計／需求／案例快照與 Git 狀態清單。"
      ],
      "findings": [
        {
          "locator": "/steps/0/actual、/steps/0/status（第 714–715 行）",
          "type": "quote",
          "text": "Evaluate returned but output stayed OFF",
          "interpretation": "回報者將此步記為 FAIL。日誌記有相同的操作結果。"
        },
        {
          "locator": "/case_id、/sut_version、/environment、/operator、/steps/0/at",
          "type": "paraphrase",
          "text": "synthetic-tester 於 2026-11-14T10:00:01+08:00 回報 TC-001（fixture-build-7，synthetic-lab）。"
        }
      ],
      "limitations": [
        "同一份回報與附檔屬同一事件，缺獨立重現、完整執行分母、現場暴露量與統計觀測期間。"
      ],
      "reader": "Codex",
      "evidence_refs": [
        {
          "path": "qa/evidence/failure.log",
          "sha256": "077d6fb7d0c5ffb3f1fcea0048d592131a4c6d1d9e1043c51667b1293d53793c"
        }
      ],
      "seq": 1,
      "recorded_at": "2026-11-23T06:02:34+00:00",
      "read_at": null
    }
  ]
}
```

## SRC-002

閱讀：已讀指定範圍（依紀錄）；採納：confirmed；用途：experience

```json
{
  "reading_state": {
    "status": "scoped",
    "label": "已讀指定範圍（依紀錄）",
    "seq": 1,
    "read_scope": [
      "第 2–7、704–705、708–717 行",
      "執行編號、狀態、案例、版本、環境、時間、回報者及步驟的實際觀察和證據清單。"
    ],
    "unread_scope": [
      "未逐欄閱讀內嵌的重複設計／需求／案例快照與 Git 狀態清單。"
    ],
    "limitations": [
      "步驟的 evidence 陣列為空，無獨立供電記錄。這筆回報只支持該次無法執行。"
    ]
  },
  "readings": [
    {
      "source_sha256": "105eb1557b22496fb0749908ccfc3177d788ab3ba41e6b1e1d344d6116ccc596",
      "status": "scoped",
      "depth": "content",
      "purpose": "判讀回報者提供的合成紀錄，評估輸出控制風險與可執行性。",
      "method": "解析 UTF-8 JSON，按 JSON 路徑與帶行號的原文核對，使用 check-run 檢查快照及證據完整性。",
      "read_scope": [
        "第 2–7、704–705、708–717 行",
        "執行編號、狀態、案例、版本、環境、時間、回報者及步驟的實際觀察和證據清單。"
      ],
      "unread_scope": [
        "未逐欄閱讀內嵌的重複設計／需求／案例快照與 Git 狀態清單。"
      ],
      "findings": [
        {
          "locator": "/steps/0/actual、/steps/0/status（第 714–715 行）",
          "type": "quote",
          "text": "Fixture power unavailable; evaluate not performed",
          "interpretation": "回報者將此步記為 BLOCKED，未操作 evaluate，無從判讀該次產品輸出。"
        },
        {
          "locator": "/case_id、/sut_version、/environment、/operator、/steps/0/at",
          "type": "paraphrase",
          "text": "synthetic-tester 於 2026-11-14T10:10:01+08:00 回報 TC-001（fixture-build-7，synthetic-lab）。"
        }
      ],
      "limitations": [
        "步驟的 evidence 陣列為空，無獨立供電記錄。這筆回報只支持該次無法執行。"
      ],
      "reader": "Codex",
      "evidence_refs": [],
      "seq": 1,
      "recorded_at": "2026-11-23T06:02:35+00:00",
      "read_at": null
    }
  ]
}
```

## SRC-003

閱讀：已讀指定範圍（依紀錄）；採納：confirmed；用途：experience

```json
{
  "reading_state": {
    "status": "scoped",
    "label": "已讀指定範圍（依紀錄）",
    "seq": 1,
    "read_scope": [
      "第 1 行（全文），含時間、初態、返回標記、觀測值與記錄的預期值。"
    ],
    "unread_scope": [],
    "limitations": [
      "僅有一步的觀察。版本和環境來自關聯執行回報，日誌未記根因、實機後果或修復結果。"
    ]
  },
  "readings": [
    {
      "source_sha256": "077d6fb7d0c5ffb3f1fcea0048d592131a4c6d1d9e1043c51667b1293d53793c",
      "status": "scoped",
      "depth": "content",
      "purpose": "判讀回報者提供的合成紀錄，評估輸出控制風險與可執行性。",
      "method": "逐行閱讀 UTF-8 文字，實算 SHA-256 並與失敗步驟的附件指紋比對。",
      "read_scope": [
        "第 1 行（全文），含時間、初態、返回標記、觀測值與記錄的預期值。"
      ],
      "unread_scope": [],
      "findings": [
        {
          "locator": "第 1 行",
          "type": "quote",
          "text": "2026-11-14T10:00:01+08:00 initial=OFF evaluate_returned=true observed=OFF expected=ON",
          "interpretation": "初態與返回後觀測均為 OFF。依據同時刻步驟的路徑與檔案指紋，確認這是第一份回報的附檔。ON 的驗收依據另見已確認規格。"
        }
      ],
      "limitations": [
        "僅有一步的觀察。版本和環境來自關聯執行回報，日誌未記根因、實機後果或修復結果。"
      ],
      "reader": "Codex",
      "evidence_refs": [],
      "seq": 1,
      "recorded_at": "2026-11-23T06:02:35+00:00",
      "read_at": null
    }
  ]
}
```

