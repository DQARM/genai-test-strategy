# 規格問題交接單

## 編號說明

ID＝Identifier（識別碼）。數字後綴是各類流水號，不代表優先度、版本、核可或測試結果。非數字後綴是專案標籤。

- Q＝Question；待釐清問題；追蹤未決事項、責任人與確認時點
- REQ＝Requirement；需求；追蹤單一產品需求
- RISK＝Risk；風險；追蹤失敗情境、影響與取捨
- SC＝Scenario；測試情境；表示待選或已選的測試情境
- SRC＝Source；資料來源；追蹤文件、操作指南或其他依據
- TC＝Test Case；測試案例；保存完整前置、步驟、判準與證據要求

由 registry.questions 產生；這是未決清單，不是逐字訪談或已確認規格。
請另存填答副本；重新匯出會更新本檔。回覆需保留回答者、日期與依據，再由設計端更新原問答／決策。空白不是同意。
列出 open 與 deferred；已標阻塞優先，其次未分級、重要及稍後。排序不代表已接受風險。
設計版本：`8b2164c1eeb47004ab6803a7ef8f96b4d932d117facd2f14806adbf7acc4e796`

## 未決摘要

| 問題 | 狀態／急迫性 | 內容 | 責任人／確認時點 | 影響 |
|---|---|---|---|---|
| Q-001 | open / blocking | 在所指的重新啟動完成後、下一次 evaluate 前，輸出應遵循什麼規則？這項規則是否取決於重啟前的輸出？ | unassigned / 制定重啟驗收條件前 | REQ-002, SC-002, TC-002, RISK-002 |
| Q-002 | open / blocking | 在隔離測具中，如何重現規格所指的重啟、辨識其完成，並在下一次 evaluate 前取得可留存的首個輸出？ | unassigned / 將重啟案例改為可執行前 | SC-002, TC-002 |

## 已登錄來源的閱讀範圍

僅顯示登錄紀錄；未登錄的文件、未讀部分及尚未分析的內容不視為已審完。

- SRC-SPEC：已讀指定範圍（依紀錄）；已讀：spec.md 第 1 至 1 行（全文）；未讀／限制：本行未定義重新啟動後、再次 evaluate 前的輸出。
- SRC-HARNESS：已讀指定範圍（依紀錄）；已讀：harness.md 第 1 至 1 行（全文）；未讀／限制：未載重啟方式、完成訊號或如何在首個 evaluate 前讀值。
- SRC-NEW：已讀指定範圍（依紀錄）；已讀：addendum.md 第 1 至 2 行（全文）；未讀／限制：未提供重啟後的輸出值、判定時點或可核對的新決策原件。

## Q-001：在所指的重新啟動完成後、下一次 evaluate 前，輸出應遵循什麼規則？這項規則是否取決於重啟前的輸出？

- 類型：ambiguity
- 分歧與影響：既有 ON 判準適用於 evaluate 後。若重啟行為應保留先前狀態，需要分別建立不同初態。如需固定初值，需提供該值及開始生效的事件。
- 責任人：unassigned；建議轉交：產品規格決策者（PM）
- 確認時點：制定重啟驗收條件前；阻塞階段：baseline, execution
- 影響項目：REQ-002, SC-002, TC-002, RISK-002

來源與具體定位：

- [SRC-NEW](../inputs/addendum.md)；版本：未提供；SHA256：440bf8cad8af68909d13960c0ebdaa46e5613ab4107acb6bc9ce62f4c12d4987
- [SRC-SPEC](../inputs/spec.md)；版本：未提供；SHA256：f574cfbae3eedc1dc70434c467a38a47a2b550511edfdef06c16521d9c0ba691
- SRC-NEW／閱讀 1／摘錄 1：addendum.md 第 1 行；新增草稿：重新啟動後的輸出尚未決定。
- SRC-SPEC／閱讀 2／摘錄 1：spec.md 第 1 行；Synthetic test rule: after evaluate, output ON.

回答（待填）：

回答者／日期／依據（待填）：


## Q-002：在隔離測具中，如何重現規格所指的重啟、辨識其完成，並在下一次 evaluate 前取得可留存的首個輸出？

- 類型：testability
- 分歧與影響：操作說明僅列 reset、evaluate、inspect output。需要適用的測具版本、重啟操作及讀值依據，以免把 reset 或第一次 evaluate 的結果視為重啟輸出。
- 責任人：unassigned；建議轉交：測具維護工程師
- 確認時點：將重啟案例改為可執行前；阻塞階段：execution
- 影響項目：SC-002, TC-002

來源與具體定位：

- [SRC-HARNESS](../inputs/harness.md)；版本：未提供；SHA256：6050ea2d883af7e763867cd2cc9320f8347986265482bc05f42bc28ee325c140
- [SRC-NEW](../inputs/addendum.md)；版本：未提供；SHA256：440bf8cad8af68909d13960c0ebdaa46e5613ab4107acb6bc9ce62f4c12d4987
- SRC-HARNESS／閱讀 2／摘錄 1：harness.md 第 1 行；Synthetic harness: reset, evaluate, inspect output; isolated state.
- SRC-NEW／閱讀 1／摘錄 1：addendum.md 第 1 行；新增草稿：重新啟動後的輸出尚未決定。

回答（待填）：

回答者／日期／依據（待填）：

