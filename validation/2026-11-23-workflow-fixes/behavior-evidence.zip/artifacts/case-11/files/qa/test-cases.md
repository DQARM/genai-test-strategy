# 測試案例設計

## 編號說明

ID＝Identifier（識別碼）。以下為本專案採用的前綴含義；不是通用強制標準。
純數字後綴如 01／001 是該類別的流水號，不代表優先度、版本、確認狀態或測試結果。
非數字後綴是專案標籤，具體含義須依來源記錄確認；RISK／RUN 本身是英文單字。

| 前綴 | 英文來源 | 中文意思 | 用途 |
|---|---|---|---|
| AC | Acceptance Criterion | 驗收條件 | 定義可觀測且可判定的產品條件 |
| COV | Coverage | 覆蓋項目 | 表示測試方法導出的分區、邊界、組合或轉移；COV 取自 Coverage |
| Q | Question | 待釐清問題 | 追蹤未決事項、責任人與確認時點 |
| RISK | Risk | 風險 | 追蹤失敗情境、影響與取捨 |
| SC | Scenario | 測試情境 | 表示待選或已選的測試情境 |
| SRC | Source | 資料來源 | 追蹤文件、操作指南或其他依據 |
| TC | Test Case | 測試案例 | 保存完整前置、步驟、判準與證據要求 |

由 cases/*.json 產生。Actual 與執行判定另存 runs；本檔不是執行報告。

## TC-001 — Evaluate changes OFF to ON

狀態：ready；revision：1

**purpose**

```json
"Detect missing output"
```

**ac_ids**

```json
[
  "AC-001"
]
```

**risk_ids**

```json
[
  "RISK-001"
]
```

**scenario_ids**

```json
[
  "SC-001"
]
```

**coverage_ids**

```json
[
  "COV-001"
]
```

**environment**

```json
{
  "target": "isolated fixture",
  "build_binding": "record fixture version at run",
  "tools": "fixture v1",
  "binding_refs": [
    "SRC-HARNESS"
  ],
  "source_citations": [
    {
      "source_id": "SRC-HARNESS",
      "reading_seq": 1,
      "finding_index": 1
    }
  ]
}
```

**preconditions**

```json
[
  {
    "action": "reset fixture to OFF",
    "verify": "read output OFF"
  }
]
```

**data**

```json
[
  {
    "name": "initial",
    "value": "OFF",
    "unit": "discrete",
    "basis": "SRC-HARNESS",
    "source_citations": [
      {
        "source_id": "SRC-HARNESS",
        "reading_seq": 1,
        "finding_index": 1
      }
    ]
  }
]
```

| 步驟 | 操作／輸入 | 觀測／時機 | Expected／依據 | 證據 |
|---|---|---|---|---|
| 1 | evaluate once / OFF | output / on return | output ON [AC-001, COV-001] | capture fixture JSON |

**cleanup**

```json
[
  {
    "action": "close fixture",
    "verify": "process terminated"
  }
]
```

**independence**

```json
"fresh process each case"
```

**verdict_rules**

```json
{
  "pass": "ON",
  "fail": "not ON with valid input",
  "inconclusive": "no output"
}
```

**blockers**

```json
[]
```

**automation**

```json
null
```

## TC-002 — 觀察重新啟動前後的輸出（受阻草稿）

狀態：blocked；revision：1

**purpose**

```json
"在重啟並恢復觀測時，區分第一個輸出與後續 evaluate 所造成的輸出。"
```

**ac_ids**

```json
[]
```

**risk_ids**

```json
[
  "RISK-002"
]
```

**scenario_ids**

```json
[
  "SC-002"
]
```

**coverage_ids**

```json
[]
```

**environment**

```json
{
  "target": "隔離的模組測具",
  "build_binding": "待工程提供可區分重啟與 reset 的測具版本及操作文件。",
  "tools": "現有測具說明列出 reset、evaluate、inspect output。",
  "binding_refs": [
    "SRC-HARNESS"
  ],
  "source_citations": [
    {
      "source_id": "SRC-HARNESS",
      "reading_seq": 2,
      "finding_index": 1
    }
  ]
}
```

**preconditions**

```json
[
  {
    "action": "待重啟規則確定後，在獨立測具中建立規則要求的前態。",
    "verify": "用 inspect output 核對並記錄重啟前的輸出。"
  }
]
```

**data**

```json
[
  {
    "reason": "初態集合由產品決策確定，目前僅記錄已建立之初態。"
  }
]
```

| 步驟 | 操作／輸入 | 觀測／時機 | Expected／依據 | 證據 |
|---|---|---|---|---|
| 1 | 待工程提供重啟操作及完成訊號後，依該版說明觸發重啟；保留事件紀錄。 / 已記錄重啟前輸出的隔離測具。 | 辨識重啟完成事件及是否已有 evaluate 發生。 / 重啟過程至確認完成時。 |  | 保留測具版本、重啟前讀值與事件順序。 |
| 2 | 於產品確認的觀測時點使用可驗證的讀值方式取得輸出。 / 同一次重啟。 | 記錄首個可取得的模組輸出。 / 確切取樣事件由 Q-001 決定，可讀時機由 Q-002 核實。 |  | 保存取樣輸出及與重啟、下次 evaluate 的先後。 |

**cleanup**

```json
[
  {
    "action": "依既有測具案例結束隔離實例。",
    "verify": "確認結束後另開獨立實例，重新建立每次初態。"
  }
]
```

**independence**

```json
"每種初態獨立建立及讀回，重新啟動的可重現性由工程提供。"
```

**verdict_rules**

```json
{
  "inconclusive": "規則或操作觀測依據未齊，無法給產品判定。"
}
```

**blockers**

```json
[
  "Q-001",
  "Q-002"
]
```

**automation**

```json
null
```

