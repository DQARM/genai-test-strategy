# 規格與待確認事項

## 編號說明

ID＝Identifier（識別碼）。以下為本專案採用的前綴含義；不是通用強制標準。
純數字後綴如 01／001 是該類別的流水號，不代表優先度、版本、確認狀態或測試結果。
非數字後綴是專案標籤，具體含義須依來源記錄確認；RISK／RUN 本身是英文單字。

| 前綴 | 英文來源 | 中文意思 | 用途 |
|---|---|---|---|
| AC | Acceptance Criterion | 驗收條件 | 定義可觀測且可判定的產品條件 |
| DEC | Decision | 決策 | 記錄人的決定與依據 |
| Q | Question | 待釐清問題 | 追蹤未決事項、責任人與確認時點 |
| REQ | Requirement | 需求 | 追蹤單一產品需求 |
| SRC | Source | 資料來源 | 追蹤文件、操作指南或其他依據 |

由 registry.json 產生；請修改來源記錄，不直接修改本檔。

## 需求

| ID | 狀態 | 內容 | 依據／責任 |
|---|---|---|---|
| REQ-001 | confirmed | Output must be ON after evaluate | ['SRC-SPEC', 'DEC-001'] |
| REQ-002 | proposed | 重新啟動後的輸出待確認 | ['SRC-NEW'] |

## 驗收條件

| ID | 狀態 | 內容 | 依據／責任 |
|---|---|---|---|
| AC-001 | confirmed | Output must be ON after evaluate | ['SRC-SPEC', 'DEC-001'] |

## 待確認

| ID | 狀態 | 內容 | 依據／責任 |
|---|---|---|---|
| Q-001 | open | 在所指的重新啟動完成後、下一次 evaluate 前，輸出應遵循什麼規則？這項規則是否取決於重啟前的輸出？ | ['unassigned', '制定重啟驗收條件前'] |
| Q-002 | open | 在隔離測具中，如何重現規格所指的重啟、辨識其完成，並在下一次 evaluate 前取得可留存的首個輸出？ | ['unassigned', '將重啟案例改為可執行前'] |

